# Loan Management Application

Welcome to the Loan Management Application! This application provides a seamless experience for managing loans, offering features for both administrators and users. Let's get started by ensuring everything is set up correctly.

## Prerequisites

Before running the application, ensure you have the following prerequisites:

1. **Python**: Make sure Python is installed on your system. You can download it from [python.org](https://www.python.org/downloads/) and follow the installation instructions.

2. **Dependencies**: Install the required dependencies by running the following command in your terminal:

   ```bash
   pip install -r requirements.txt
   ```

3. **Configuration**: Create a `.env` file in the same directory as `app.py` and replace the placeholders with your actual configuration details. These configurations are crucial for the application's proper functioning, especially for enabling email sending functionality.

   ```dotenv
   # Configuration Details
   SQLALCHEMY_DATABASE_URI="sqlite:///dummy_database.db"
   SECRET_KEY="DummySecretKey123"
   MAIL_SERVER="smtp.example.com"
   MAIL_PORT=587
   MAIL_USE_TLS=True
   MAIL_USE_SSL=False
   MAIL_USERNAME="example@gmail.com"
   MAIL_PASSWORD="DummyMailPassword123"
   MAIL_DEFAULT_SENDER="example@gmail.com"
   MAIL_MAX_EMAILS=None
   MAIL_ASCII_ATTACHMENTS=False
   ```

   Please note that for security reasons, actual details are not exposed here. If you need assistance, feel free to contact [Levi.](https://github.com/Levi-LMN)

## Running the Application

To run the application, execute the following command in your terminal:

```bash
python app.py
```

After running the command, the application will be accessible at `http://127.0.0.1:5000/`.

## Usage

Once the application is up and running, you can perform the following actions:

- **User Registration**: Users can register with their personal details, including email and password.
- **Email Confirmation**: A confirmation email is sent to verify the user's email address.
- **User Authentication**: Secure user authentication system ensures only authorized users can access the application.
- **Password Reset**: Users can reset their passwords through a password
