from flask import Flask, render_template, request, redirect, url_for, flash
from flask_sqlalchemy import SQLAlchemy
from werkzeug.security import check_password_hash, generate_password_hash
from flask_login import LoginManager, UserMixin, login_user, login_required, logout_user, current_user
from flask_mail import Mail, Message
from itsdangerous import URLSafeTimedSerializer
from flask import abort
from models import db, User, PersonalDetails, Loan, Repayment
from config import app

# Initialize the serializer with  app's secret key
serializer = URLSafeTimedSerializer(app.config['SECRET_KEY'])

mail = Mail(app)
db.init_app(app)
login_manager = LoginManager(app)

# Create tables in the database
with app.app_context():
    db.create_all()


@login_manager.user_loader
def load_user(user_id):
    return User.query.get(int(user_id))


# User registration route
@app.route('/register', methods=['GET', 'POST'])
def register():
    if request.method == 'POST':
        # Get user input from the registration form
        first_name = request.form.get('first_name')
        last_name = request.form.get('last_name')
        email = request.form.get('email')
        password = request.form.get('password')

        # Check if the email is already registered
        existing_user = User.query.filter_by(email=email).first()
        if existing_user:
            flash('Email already registered. Choose another email.', 'error')
            return redirect(url_for('register'))

        # Hash the password before storing it in the database
        hashed_password = generate_password_hash(password)

        # Create a new user without specifying the 'role' here
        new_user = User(
            first_name=first_name,
            last_name=last_name,
            email=email,
            password=hashed_password
        )

        # Set the default 'user' role before adding the user to the database
        new_user.role = 'user'

        # Add the user to the database
        db.session.add(new_user)
        db.session.commit()

        # Send email confirmation
        send_confirmation_email(new_user)

        flash('Registration successful.You can now login \n Please check your email to confirm your account.',
              'success')

        return redirect(url_for('login'))

    return render_template('user/register.html')


# Function to generate confirmation token
def generate_confirmation_token(email):
    return serializer.dumps(email, salt='email-confirm')


# Route to handle email confirmation
@app.route('/confirm_email/<token>')
def confirm_email(token):
    try:
        # Decrypt the token to get the email
        email = serializer.loads(token, salt='email-confirm', max_age=3600)  # Token expires after 1 hour (3600 seconds)

        # Find the user by email
        user = User.query.filter_by(email=email).first()
        if user:
            # Set user verification to True
            user.verification = True
            db.session.commit()
            flash('Email confirmed successfully. You can now reset your password if you forget it.', 'success')
            return redirect(url_for('user_profile', message='Your email has been successfully verified.'))
        else:
            flash('Invalid token or user not found.', 'error')
            return redirect(url_for('index'))
    except Exception as e:
        flash('Invalid or expired token.', 'error')
        return redirect(url_for('index'))


# Function to send email confirmation
def send_confirmation_email(user):
    token = generate_confirmation_token(user.email)
    confirm_url = url_for('confirm_email', token=token, _external=True)
    message_body = f'Hi {user.first_name},\n\nPlease click the following link to confirm your email address:\n{confirm_url}'
    msg = Message('Confirm Your Email Address', sender='your-email@example.com', recipients=[user.email])
    msg.body = message_body
    mail.send(msg)


# Registration route for admin users
@app.route('/register_admin', methods=['GET', 'POST'])
def register_admin():
    if request.method == 'POST':
        # Get admin user input from the registration form
        first_name = request.form.get('first_name')
        last_name = request.form.get('last_name')
        email = request.form.get('email')
        password = request.form.get('password')

        # Check if the email is already registered
        existing_user = User.query.filter_by(email=email).first()
        if existing_user:
            return render_template('admin/register.html', message='Email already registered. Choose another email.')

        # Hash the password before storing it in the database
        hashed_password = generate_password_hash(password)

        # Create a new admin user without specifying the 'role' here
        new_admin_user = User(
            first_name=first_name,
            last_name=last_name,
            email=email,
            password=hashed_password
        )

        # Set the 'admin' role before adding the admin user to the database
        new_admin_user.role = 'admin'

        # Add the admin user to the database
        db.session.add(new_admin_user)
        db.session.commit()

        return redirect(url_for('login'))

    return render_template('admin/register.html')


# Landing page route
@app.route('/')
def index():
    # Check if the user is already logged in
    if current_user.is_authenticated:
        # Redirect to the respective dashboard based on the user's role
        if current_user.role == 'admin':
            return redirect(url_for('admin_dashboard'))
        else:
            return redirect(url_for('user_dashboard'))

    # If not logged in, render the landing page
    return render_template('index.html')


# Universal login route
@app.route('/login', methods=['GET', 'POST'])
def login():
    if request.method == 'POST':
        email = request.form.get('email')
        password = request.form.get('password')

        # Check if the user exists in the database
        user = User.query.filter_by(email=email).first()

        if user and check_password_hash(user.password, password):
            # Log in the user using Flask-Login
            login_user(user)

            # Redirect based on the user's role
            if user.role == 'admin':
                return redirect(url_for('admin_dashboard'))
            else:
                return redirect(url_for('user_dashboard'))

        # Authentication failed
        return render_template('login.html', message='Invalid email or password.')

    return render_template('login.html')


# User dashboard route
@app.route('/user_dashboard')
@login_required
def user_dashboard():
    # Check if the user is logged in as a regular user
    if current_user.role == 'user':
        return render_template('user/user_dashboard.html', current_user=current_user)
    else:
        flash('You are not authorized to access this page.', 'error')
        return redirect(url_for('admin_dashboard'))


# Admin dashboard route
@app.route('/admin_dashboard')
@login_required
def admin_dashboard():
    # Check if the user is logged in as an admin
    if current_user.role == 'admin':
        return render_template('admin/admin_dashboard.html')
    else:
        flash('You are not authorized to access this page.', 'error')
        return redirect(url_for('user_dashboard'))


# User profile route
@app.route('/user_profile')
@login_required
def user_profile():
    message = request.args.get('message')
    return render_template('user/profile.html', current_user=current_user, message=message)


# Logout route
@app.route('/logout')
@login_required
def logout():
    # Log out the user using Flask-Login
    logout_user()
    return redirect(url_for('login'))


# Function to calculate loan amount based on salary
def calculate_loan_amount(salary):
    # loan calculation algorithm
    if salary < 50000:
        return 10000  # Minimum loan amount
    elif 50000 <= salary < 100000:
        return 20000
    elif 100000 <= salary < 150000:
        return 30000
    else:
        return 50000  # Maximum loan amount


# User personal details route
@app.route('/add_personal_details', methods=['GET', 'POST'])
@login_required
def add_personal_details():
    if request.method == 'POST':
        # Get personal details input from the form
        marital_status = request.form.get('marital_status')
        education_level = request.form.get('education_level')
        salary = float(request.form.get('salary'))
        address = request.form.get('address')
        resident_type = request.form.get('resident_type')
        kra_pin = request.form.get('kra_pin')
        national_id = request.form.get('national_id')

        # Create a new PersonalDetails object and associate it with the current user
        new_personal_details = PersonalDetails(
            marital_status=marital_status,
            education_level=education_level,
            salary=salary,
            address=address,
            resident_type=resident_type,
            kra_pin=kra_pin,
            national_id=national_id,
            user=current_user
        )

        # Add the personal details to the database
        db.session.add(new_personal_details)
        db.session.commit()

        # Calculate loan amount
        loan_amount = calculate_loan_amount(salary)

        # Send email notification for successful addition of personal details along with loan information
        send_personal_details_confirmation_email(current_user, loan_amount)

        return redirect(url_for('user_dashboard'))

    return render_template('user/add_personal_details.html', current_user=current_user)


# Function to send email notification for successful addition of personal details with loan information
def send_personal_details_confirmation_email(user, loan_amount):
    message_body = f'Hi {user.first_name},\n\nYou have successfully added your personal details.\n\nBased on your salary, you are eligible for a loan of {loan_amount} KSH.'
    msg = Message('Personal Details Added Successfully', sender='your-email@example.com', recipients=[user.email])
    msg.body = message_body
    mail.send(msg)


# Route to display all users
@app.route('/all_users')
@login_required
def all_users():
    # Fetch all users from the database
    all_users = User.query.all()
    return render_template('admin/all_users.html', all_users=all_users)


# Route to delete a user
@app.route('/delete_user/<int:user_id>', methods=['POST'])
@login_required
def delete_user(user_id):
    # Ensure only admin users can delete users
    if current_user.role != 'admin':
        abort(403)  # Forbidden

    # Find the user by ID
    user = User.query.get(user_id)
    if not user:
        abort(404)  # User not found

    # Delete the user
    db.session.delete(user)
    db.session.commit()

    flash('User deleted successfully.', 'success')
    return redirect(url_for('all_users'))


# Route to resend confirmation email
@app.route('/resend_confirmation_email')
@login_required
def resend_confirmation_email():
    if current_user.verification:
        flash('Your email is already verified.', 'info')
        return redirect(url_for('user_profile'))

    send_confirmation_email(current_user)
    flash('Confirmation email resent. Please check your email to confirm your account.', 'success')

    return redirect(url_for('user_profile'))


# Route for forgot password page
@app.route('/forgot_password', methods=['GET', 'POST'])
def forgot_password():
    if request.method == 'POST':
        email = request.form.get('email')
        user = User.query.filter_by(email=email).first()
        if user:
            if not user.verification:
                flash('Your email address is not verified. Please verify your email before resetting your password.',
                      'error')
                return redirect(url_for('forgot_password'))

            # Generate a password reset token
            token = serializer.dumps(email, salt='reset-password')

            # Send password reset email
            reset_url = url_for('reset_password', token=token, _external=True)
            message_body = f'Hi {user.first_name},\n\nPlease click the following link to reset your password:\n{reset_url}'
            msg = Message('Password Reset', sender='your-email@example.com', recipients=[user.email])
            msg.body = message_body
            mail.send(msg)

            flash('Password reset instructions have been sent to your email.', 'success')
            return redirect(url_for('login'))
        else:
            flash('No user found with that email address.', 'error')

    return render_template('user/forgot_password.html')


# Route for password reset page
@app.route('/reset_password/<token>', methods=['GET', 'POST'])
def reset_password(token):
    try:
        email = serializer.loads(token, salt='reset-password',
                                 max_age=3600)  # Token expires after 1 hour (3600 seconds)
        if request.method == 'POST':
            new_password = request.form.get('new_password')
            confirm_password = request.form.get('confirm_password')

            if new_password == confirm_password:
                # Update the user's password
                user = User.query.filter_by(email=email).first()
                if user:
                    user.password = generate_password_hash(new_password)
                    db.session.commit()
                    flash('Password reset successfully. You can now log in with your new password.', 'success')
                    return redirect(url_for('login'))
                else:
                    flash('No user found with that email address.', 'error')
            else:
                flash('Passwords do not match.', 'error')
    except:
        flash('Invalid or expired token.', 'error')

    return render_template('user/reset_password.html', token=token)


if __name__ == '__main__':
    app.run(debug=True)
