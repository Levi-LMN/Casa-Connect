from flask import Flask
from dotenv import load_dotenv
import os

# Load variables from .env file
load_dotenv()

app = Flask(__name__)
app.config['SQLALCHEMY_DATABASE_URI'] = os.getenv('SQLALCHEMY_DATABASE_URI')
app.config['SECRET_KEY'] = os.getenv('SECRET_KEY')
app.config['SQLALCHEMY_TRACK_MODIFICATIONS'] = False
app.config['MAIL_SERVER'] = os.getenv('MAIL_SERVER')
app.config['MAIL_PORT'] = int(os.getenv('MAIL_PORT'))
app.config['MAIL_USE_TLS'] = os.getenv('MAIL_USE_TLS').lower() == 'true'
app.config['MAIL_USE_SSL'] = os.getenv('MAIL_USE_SSL').lower() == 'true'
app.config['MAIL_USERNAME'] = os.getenv('MAIL_USERNAME')
app.config['MAIL_PASSWORD'] = os.getenv('MAIL_PASSWORD')
app.config['MAIL_DEFAULT_SENDER'] = os.getenv('MAIL_DEFAULT_SENDER')
app.config['MAIL_MAX_EMAILS'] = os.getenv('MAIL_MAX_EMAILS')
app.config['MAIL_ASCII_ATTACHMENTS'] = os.getenv('MAIL_ASCII_ATTACHMENTS').lower() == 'true'

'''
Configuration Details:
----------------------

SQLALCHEMY_DATABASE_URI = "sqlite:///dummy_database.db"
    - Description: Specifies the URI for the SQLite database.
    - Example: "sqlite:///dummy_database.db"

SECRET_KEY = "DummySecretKey123"
    - Description: Secret key used for cryptographic operations in Flask.
    - Example: "DummySecretKey123"

MAIL_SERVER = "smtp.gmail.com"
    - Description: Specifies the SMTP server for sending emails.
    - Example: "smtp.gmail.com"

MAIL_PORT = 587
    - Description: Specifies the port number for the email server.
    - Example: 587

MAIL_USE_TLS = True
    - Description: Indicates whether TLS should be used for email communication.
    - Example: True

MAIL_USE_SSL = False
    - Description: Indicates whether SSL should be used for email communication.
    - Example: False

MAIL_USERNAME = "example6@gmail.com"
    - Description: Specifies the username for the email server.
    - Example: "kedevops6@gmail.com"

MAIL_PASSWORD = "password"
    - Description: Specifies the password for the email server.
    - Example: "12345678"

MAIL_DEFAULT_SENDER = "example@gmail.com"
    - Description: Specifies the default sender for outgoing emails.
    - Example: ("Quick Loans", "kedevops6@gmail.com")

MAIL_MAX_EMAILS = None
    - Description: Specifies the maximum number of emails to be sent in a single connection. None indicates unlimited.
    - Example: None

MAIL_ASCII_ATTACHMENTS = False
    - Description: Specifies whether non-ASCII attachments should be converted to ASCII.
    - Example: False
'''

