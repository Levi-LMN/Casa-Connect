from flask import Flask
from flask_mail import Mail
from flask_login import LoginManager
from itsdangerous import URLSafeTimedSerializer
from flask_sqlalchemy import SQLAlchemy

app = Flask(__name__)
app.config.from_object('config')

mail = Mail(app)
db = SQLAlchemy(app)
login_manager = LoginManager(app)

# Initialize the serializer with your app's secret key
serializer = URLSafeTimedSerializer(app.config['SECRET_KEY'])

from app import user_routes, admin_routes  # Import routes after app is created

# Create tables in the database
with app.app_context():
    db.create_all()
