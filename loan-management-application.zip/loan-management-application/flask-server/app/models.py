from flask_sqlalchemy import SQLAlchemy
from flask_login import UserMixin

db = SQLAlchemy()

# User Model
class User(db.Model, UserMixin):
    """
    Represents a user in the application.

    Attributes:
        id (int): The unique identifier for the user.
        first_name (str): The first name of the user.
        last_name (str): The last name of the user.
        email (str): The email address of the user.
        verification (bool): Indicates if the user's email address has been verified.
        reset_token (str): Token used for resetting the user's password.
        reset_token_expiration (datetime): Expiration date for the reset token.
        role (str): The role of the user, either 'regular' or 'admin'.
        password (str): The hashed password of the user.
        personal_details (PersonalDetails): One-to-one relationship with personal details.
        loans (List[Loan]): One-to-many relationship with loans taken by the user.

    Methods:
        get_id(): Returns the string representation of the user's ID for Flask-Login.
    """

    id = db.Column(db.Integer, primary_key=True)
    first_name = db.Column(db.String(50), nullable=False)
    last_name = db.Column(db.String(50), nullable=False)
    email = db.Column(db.String(120), unique=True, nullable=False)
    verification = db.Column(db.Boolean, default=False)
    reset_token = db.Column(db.String(120))
    reset_token_expiration = db.Column(db.DateTime)
    role = db.Column(db.String(20), default='regular')  # 'regular' or 'admin'
    password = db.Column(db.String(60), nullable=False)
    personal_details = db.relationship('PersonalDetails', backref='user', uselist=False)
    loans = db.relationship('Loan', backref='user', lazy=True)

    def get_id(self):
        return str(self.id)  # Convert user ID to string for Flask-Login


# PersonalDetails Model
class PersonalDetails(db.Model):
    """
    Represents personal details associated with a user.

    Attributes:
        id (int): The unique identifier for the personal details.
        marital_status (str): The marital status of the user.
        education_level (str): The education level of the user.
        salary (float): The salary of the user.
        address (str): The address of the user.
        resident_type (str): The type of residency, either 'foreign' or 'Kenyan'.
        kra_pin (str): The KRA PIN (Kenya Revenue Authority Personal Identification Number) of the user.
        national_id (str): The national identification number of the user.
        user_id (int): The ID of the associated user.

    Relationships:
        user (User): The user associated with these personal details.
    """

    id = db.Column(db.Integer, primary_key=True)
    marital_status = db.Column(db.String(20))
    education_level = db.Column(db.String(50))
    salary = db.Column(db.Float)
    address = db.Column(db.String(255))
    resident_type = db.Column(db.String(20))  # 'foreign' or 'Kenyan'
    kra_pin = db.Column(db.String(20))
    national_id = db.Column(db.String(20))
    user_id = db.Column(db.Integer, db.ForeignKey('user.id'), nullable=False)


# Loan Model
class Loan(db.Model):
    """
    Represents a loan taken by a user.

    Attributes:
        id (int): The unique identifier for the loan.
        salary (float): The salary of the user at the time of taking the loan.
        amount (float): The amount of the loan.
        loan_duration (int): The duration of the loan in months.
        purpose (str): The purpose of the loan.
        taken_time (datetime): The date and time when the loan was taken.
        status (str): The status of the loan, either 'approved', 'rejected', or 'in progress'.
        user_id (int): The ID of the user who took the loan.

    Relationships:
        user (User): The user who took the loan.
    """

    id = db.Column(db.Integer, primary_key=True)
    salary = db.Column(db.Float)
    amount = db.Column(db.Float)
    loan_duration = db.Column(db.Integer)
    purpose = db.Column(db.String(255))
    taken_time = db.Column(db.DateTime)
    status = db.Column(db.String(20))  # 'approved', 'rejected', or 'in progress'
    user_id = db.Column(db.Integer, db.ForeignKey('user.id'), nullable=False)


# Repayment Model
class Repayment(db.Model):
    """
    Represents a repayment for a loan.

    Attributes:
        id (int): The unique identifier for the repayment.
        amount_to_paid (float): The amount paid in this repayment.
        last_payment_date (datetime): The date of the last payment made.
        status (str): The status of the repayment, either 'full' or 'partial'.
        loan_id (int): The ID of the loan associated with this repayment.

    Relationships:
        loan (Loan): The loan associated with this repayment.
    """

    id = db.Column(db.Integer, primary_key=True)
    amount_to_paid = db.Column(db.Float)
    last_payment_date = db.Column(db.DateTime)
    status = db.Column(db.String(20))  # 'full' or 'partial'
    loan_id = db.Column(db.Integer, db.ForeignKey('loan.id'), nullable=False)
