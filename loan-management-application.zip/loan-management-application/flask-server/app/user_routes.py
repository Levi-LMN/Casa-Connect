from flask import Blueprint, render_template, request, redirect, url_for, flash, current_app
from flask_login import login_user, login_required, logout_user, current_user
from werkzeug.security import check_password_hash, generate_password_hash
from itsdangerous import URLSafeTimedSerializer
from flask_mail import Message
from models import db, User, PersonalDetails

user_routes = Blueprint('user_routes', __name__)

# Use current_app to access the Flask application instance
serializer = URLSafeTimedSerializer(current_app.config['SECRET_KEY'])

# User registration route
@user_routes.route('/register', methods=['GET', 'POST'])
def register():
    if request.method == 'POST':
        # Get user input from the registration form
        first_name = request.form.get('first_name')
        last_name = request.form.get('last_name')
        email = request.form.get('email')
        password = request.form.get('password')

        # Check if the email is already registered
        existing_user = User.query.filter_by(email=email).first()
        if existing_user:
            flash('Email already registered. Choose another email.', 'error')
            return redirect(url_for('user_routes.register'))

        # Hash the password before storing it in the database
        hashed_password = generate_password_hash(password)

        # Create a new user without specifying the 'role' here
        new_user = User(
            first_name=first_name,
            last_name=last_name,
            email=email,
            password=hashed_password
        )

        # Set the default 'user' role before adding the user to the database
        new_user.role = 'user'

        # Add the user to the database
        db.session.add(new_user)
        db.session.commit()

        # Send email confirmation
        send_confirmation_email(new_user)

        flash('Registration successful. You can now login. Please check your email to confirm your account.', 'success')

        return redirect(url_for('user_routes.login'))

    return render_template('user/register.html')


# Function to generate confirmation token
def generate_confirmation_token(email):
    return serializer.dumps(email, salt='email-confirm')


# Route to handle email confirmation
@user_routes.route('/confirm_email/<token>')
def confirm_email(token):
    try:
        # Decrypt the token to get the email
        email = serializer.loads(token, salt='email-confirm', max_age=3600)  # Token expires after 1 hour (3600 seconds)

        # Find the user by email
        user = User.query.filter_by(email=email).first()
        if user:
            # Set user verification to True
            user.verification = True
            db.session.commit()
            flash('Email confirmed successfully. You can now reset your password if you forget it.', 'success')
            return redirect(url_for('user_routes.user_profile', message='Your email has been successfully verified.'))
        else:
            flash('Invalid token or user not found.', 'error')
            return redirect(url_for('user_routes.index'))
    except Exception as e:
        flash('Invalid or expired token.', 'error')
        return redirect(url_for('user_routes.index'))


# Function to send email confirmation
def send_confirmation_email(user):
    token = generate_confirmation_token(user.email)
    confirm_url = url_for('user_routes.confirm_email', token=token, _external=True)
    message_body = f'Hi {user.first_name},\n\nPlease click the following link to confirm your email address:\n{confirm_url}'
    msg = Message('Confirm Your Email Address', sender='your-email@example.com', recipients=[user.email])
    msg.body = message_body
    mail.send(msg)


# Landing page route
@user_routes.route('/')
def index():
    # Check if the user is already logged in
    if current_user.is_authenticated:
        # Redirect to the respective dashboard based on the user's role
        if current_user.role == 'admin':
            return redirect(url_for('admin_routes.admin_dashboard'))
        else:
            return redirect(url_for('user_routes.user_dashboard'))

    # If not logged in, render the landing page
    return render_template('index.html')


# Universal login route
@user_routes.route('/login', methods=['GET', 'POST'])
def login():
    if request.method == 'POST':
        email = request.form.get('email')
        password = request.form.get('password')

        # Check if the user exists in the database
        user = User.query.filter_by(email=email).first()

        if user and check_password_hash(user.password, password):
            # Log in the user using Flask-Login
            login_user(user)

            # Redirect based on the user's role
            if user.role == 'admin':
                return redirect(url_for('admin_routes.admin_dashboard'))
            else:
                return redirect(url_for('user_routes.user_dashboard'))

        # Authentication failed
        flash('Invalid email or password.', 'error')

    return render_template('user/login.html')


# User dashboard route
@user_routes.route('/user_dashboard')
@login_required
def user_dashboard():
    # Check if the user is logged in as a regular user
    if current_user.role == 'user':
        return render_template('user/user_dashboard.html', current_user=current_user)
    else:
        flash('You are not authorized to access this page.', 'error')
        return redirect(url_for('admin_routes.admin_dashboard'))


# User profile route
@user_routes.route('/user_profile')
@login_required
def user_profile():
    message = request.args.get('message')
    return render_template('user/profile.html', current_user=current_user, message=message)


# Logout route
@user_routes.route('/logout')
@login_required
def logout():
    # Log out the user using Flask-Login
    logout_user()
    return redirect(url_for('user_routes.login'))


# User personal details route
@user_routes.route('/add_personal_details', methods=['GET', 'POST'])
@login_required
def add_personal_details():
    if request.method == 'POST':
        # Get personal details input from the form
        marital_status = request.form.get('marital_status')
        education_level = request.form.get('education_level')
        salary = float(request.form.get('salary'))
        address = request.form.get('address')
        resident_type = request.form.get('resident_type')
        kra_pin = request.form.get('kra_pin')
        national_id = request.form.get('national_id')

        # Create a new PersonalDetails object and associate it with the current user
        new_personal_details = PersonalDetails(
            marital_status=marital_status,
            education_level=education_level,
            salary=salary,
            address=address,
            resident_type=resident_type,
            kra_pin=kra_pin,
            national_id=national_id,
            user=current_user
        )

        # Add the personal details to the database
        db.session.add(new_personal_details)
        db.session.commit()

        return redirect(url_for('user_routes.user_dashboard'))

    return render_template('user/add_personal_details.html', current_user=current_user)


# Route for forgot password page
@user_routes.route('/forgot_password', methods=['GET', 'POST'])
def forgot_password():
    if request.method == 'POST':
        email = request.form.get('email')
        user = User.query.filter_by(email=email).first()
        if user:
            if not user.verification:
                flash('Your email address is not verified. Please verify your email before resetting your password.', 'error')
                return redirect(url_for('user_routes.forgot_password'))

            # Generate a password reset token
            token = serializer.dumps(email, salt='reset-password')

            # Send password reset email
            reset_url = url_for('user_routes.reset_password', token=token, _external=True)
            message_body = f'Hi {user.first_name},\n\nPlease click the following link to reset your password:\n{reset_url}'
            msg = Message('Password Reset', sender='your-email@example.com', recipients=[user.email])
            msg.body = message_body
            mail.send(msg)

            flash('Password reset instructions have been sent to your email.', 'success')
            return redirect(url_for('user_routes.login'))
        else:
            flash('No user found with that email address.', 'error')

    return render_template('user/forgot_password.html')


# Route for password reset page
@user_routes.route('/reset_password/<token>', methods=['GET', 'POST'])
def reset_password(token):
    try:
        email = serializer.loads(token, salt='reset-password', max_age=3600)  # Token expires after 1 hour (3600 seconds)
        if request.method == 'POST':
            new_password = request.form.get('new_password')
            confirm_password = request.form.get('confirm_password')

            if new_password == confirm_password:
                # Update the user's password
                user = User.query.filter_by(email=email).first()
                if user:
                    user.password = generate_password_hash(new_password)
                    db.session.commit()
                    flash('Password reset successfully. You can now log in with your new password.', 'success')
                    return redirect(url_for('user_routes.login'))
                else:
                    flash('No user found with that email address.', 'error')
            else:
                flash('Passwords do not match.', 'error')
    except:
        flash('Invalid or expired token.', 'error')

    return render_template('user/reset_password.html', token=token)
