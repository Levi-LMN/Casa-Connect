from flask import Blueprint, render_template, request, redirect, url_for, flash
from flask_login import login_required, current_user
from models import User
from config import app
from app import app, mail, serializer, db


admin_routes = Blueprint('admin_routes', __name__)


# Registration route for admin users
@admin_routes.route('/register_admin', methods=['GET', 'POST'])
def register_admin():
    if request.method == 'POST':
        # Get admin user input from the registration form
        first_name = request.form.get('first_name')
        last_name = request.form.get('last_name')
        email = request.form.get('email')
        password = request.form.get('password')

        # Check if the email is already registered
        existing_user = User.query.filter_by(email=email).first()
        if existing_user:
            return render_template('admin/register.html', message='Email already registered. Choose another email.')

        # Hash the password before storing it in the database
        hashed_password = generate_password_hash(password)

        # Create a new admin user without specifying the 'role' here
        new_admin_user = User(
            first_name=first_name,
            last_name=last_name,
            email=email,
            password=hashed_password
        )

        # Set the 'admin' role before adding the admin user to the database
        new_admin_user.role = 'admin'

        # Add the admin user to the database
        db.session.add(new_admin_user)
        db.session.commit()

        return redirect(url_for('user_routes.login'))

    return render_template('admin/register.html')


# Admin dashboard route
@admin_routes.route('/admin_dashboard')
@login_required
def admin_dashboard():
    # Check if the user is logged in as an admin
    if current_user.role == 'admin':
        return render_template('admin/admin_dashboard.html')
    else:
        flash('You are not authorized to access this page.', 'error')
        return redirect(url_for('user_routes.user_dashboard'))


# Route to display all users
@admin_routes.route('/all_users')
@login_required
def all_users():
    # Fetch all users from the database
    all_users = User.query.all()
    return render_template('admin/all_users.html', all_users=all_users)


# Route to delete a user
@admin_routes.route('/delete_user/<int:user_id>', methods=['POST'])
@login_required
def delete_user(user_id):
    # Ensure only admin users can delete users
    if current_user.role != 'admin':
        abort(403)  # Forbidden

    # Find the user by ID
    user = User.query.get(user_id)
    if not user:
        abort(404)  # User not found

    # Delete the user
    db.session.delete(user)
    db.session.commit()

    flash('User deleted successfully.', 'success')
    return redirect(url_for('admin_routes.all_users'))


# Route to resend confirmation email
@admin_routes.route('/resend_confirmation_email')
@login_required
def resend_confirmation_email():
    if current_user.verification:
        flash('Your email is already verified.', 'info')
        return redirect(url_for('user_routes.user_profile'))

    send_confirmation_email(current_user)
    flash('Confirmation email resent. Please check your email to confirm your account.', 'success')

    return redirect(url_for('user_routes.user_profile'))
